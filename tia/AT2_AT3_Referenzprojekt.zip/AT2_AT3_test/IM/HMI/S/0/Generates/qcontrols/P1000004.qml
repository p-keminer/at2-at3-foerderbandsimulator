﻿import QtQuick 2.7
import "qrc:/"
IGuiPage
{
	id: q16777220
	objId: 16777220
	x: 0
	y: 0
	width: 1280
	height: 800
	IGuiUserView
	{
		id: q536870912
		objId: 536870912
		x: 1
		y: 97
		width: 1276
		height: 647
		qm_BorderCornerRadius: 4
		qm_BorderWidth: 1
		qm_RectangleBorder.color:"#ff636973"
		qm_FillColor: "#ffe7dfde"
		IGuiListCtrl
		{
			id: qu536870912
			objectName: "qu536870912"
			x: 2
			y: 2
			width: 1272
			height: 643
			totalColumnWidth: 1238
			qm_leftImageID: 52
			qm_leftTileTop: 11
			qm_leftTileBottom: 12
			qm_leftTileRight: 2
			qm_leftTileLeft: 4
			qm_middleImageID: 53
			qm_middleTileTop: 11
			qm_middleTileBottom: 12
			qm_middleTileRight: 2
			qm_middleTileLeft: 2
			qm_rightImageID: 54
			qm_rightTileTop: 11
			qm_rightTileBottom: 12
			qm_rightTileRight: 4
			qm_rightTileLeft: 2
			qm_leftBorderCornerRadius: 2
			qm_tableBackColor: "#ffffffff"
			qm_tableSelectBackColor: "#ff94b6e7"
			qm_tableAlternateBackColor: "#ffe7e7ef"
			qm_tableHeaderBackColor: "#ffefebef"
			qm_tableTextColor: "#ff31344a"
			qm_tableSelectTextColor: "#ff31344a"
			qm_tableAlternateTextColor: "#ff31344a"
			qm_tableMarginLeft: 2
			qm_tableMarginRight: 1
			qm_tableMarginBottom: 1
			qm_tableMarginTop: 1
			qm_tableHeaderTextColor: "#ff31344a"
			qm_tableHeaderValueVarTextAlignmentHorizontal: Text.AlignLeft
			qm_tableHeaderValueVarTextAlignmentVertical: Text.AlignVCenter
			qm_tableHeaderMarginLeft: 3
			qm_tableHeaderMarginRight: 1
			qm_tableHeaderMarginBottom: 1
			qm_tableHeaderMarginTop: 1
			qm_gridLineStyle: 0
			qm_gridLineWidth: 1
			qm_gridLineColor: "#ffffffff"
			qm_noOfColumns: 4
			qm_tableRowHeight: 21
			qm_tableHeaderHeight: 21
			qm_hasHeader: true
			qm_hasGridLines: true
			qm_hasBorder: true
			qm_hasDisplayFocusLine: true
			qm_hasVerticalScrolling: true
			qm_hasVerticalScrollBar: true
			qm_hasHorizontalScrollBar: true
			qm_hasColumnOrdering: false
			qm_hasHighLightFullRow: false
			qm_hasVerUpDownPresent: false
			qm_hasVerPgUpDownPresent: false
			qm_hasHighlight: true
			qm_hasUpDownAsPageUpDown: false
			qm_hasLongAlarmButton: false
			qm_hasExtraPixelForLineHeight: false
			qm_hasRowEditable: true
			qm_hasRowJustification: false
			qm_hasRowJustificationBottom: false
			qm_linesPerRow: 1
			qm_scrollCtrl: qus536870912

			IGuiListColumnView
			{
				id: qc120000000
				colIndex: 0
				x: 0
				y: 0
				width: 156
				height: 611
				columnType: 0
				qm_columnValueVarTextAlignmentHorizontal: Text.AlignLeft
				qm_columnValueVarTextAlignmentVertical: Text.AlignVCenter
			}
			IGuiListColumnView
			{
				id: qc220000000
				colIndex: 1
				x: 156
				y: 0
				width: 882
				height: 611
				columnType: 0
				qm_columnValueVarTextAlignmentHorizontal: Text.AlignLeft
				qm_columnValueVarTextAlignmentVertical: Text.AlignVCenter
			}
			IGuiListColumnView
			{
				id: qc320000000
				colIndex: 2
				x: 1038
				y: 0
				width: 80
				height: 611
				columnType: 0
				qm_columnValueVarTextAlignmentHorizontal: Text.AlignLeft
				qm_columnValueVarTextAlignmentVertical: Text.AlignVCenter
			}
			IGuiListColumnView
			{
				id: qc420000000
				colIndex: 3
				x: 1118
				y: 0
				width: 120
				height: 611
				columnType: 0
				qm_columnValueVarTextAlignmentHorizontal: Text.AlignLeft
				qm_columnValueVarTextAlignmentVertical: Text.AlignVCenter
			}
			IGuiScrollBarCtrl
			{
				id: qus536870912

			}
		}
	}
	IGuiButton
	{
		id: q486539318
		objId: 486539318
		x: 1
		y: 49
		width: 159
		height: 47
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 1
		qm_ImageSource: "image://QSmartImageProvider/21#2#4#128#0#0"
		qm_Border.top: 15
		qm_Border.bottom: 15
		qm_Border.right: 5
		qm_Border.left: 5
		qm_FillColor: "#ffe7e3e7"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 1
		qm_Anchors.leftMargin: 1
		qm_Anchors.rightMargin: 1
		qm_Anchors.topMargin: 1
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
}
