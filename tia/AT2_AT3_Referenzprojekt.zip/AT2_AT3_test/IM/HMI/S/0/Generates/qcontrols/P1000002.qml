﻿import QtQuick 2.7
import "qrc:/"
IGuiPage
{
	id: q16777218
	objId: 16777218
	x: 0
	y: 0
	width: 1280
	height: 800
	IGuiDiagnosticView
	{
		id: q788529152
		objId: 788529152
		x: 1
		y: 97
		width: 1276
		height: 647
		qm_BorderCornerRadius: 4
		qm_BorderWidth: 1
		qm_RectangleBorder.color:"#ff636973"
		qm_FillColor: "#f7f3f7"
		qm_headerBackColor: "#f7f3f7"
		qm_toolBarBackColor: "#f7f3f7"
		qm_headerTextColor: "#ff31344a"
		qm_headerValueVarTextAlignmentHorizontal: Text.AlignLeft
		qm_headerValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_headerMarginLeft: 2
		qm_headerMarginRight: 1
		qm_headerMarginBottom: 1
		qm_headerMarginTop: 1
		qm_FocusWidth: 2
		qm_FocusColor: "#ffa5cfd6"
		qm_diagViewToolbarPosX: 2
		qm_diagViewToolbarPosY: 595
		qm_diagViewToolbarWidth: 1272
		qm_diagViewToolbarHeight: 50
		qm_Font.pixelSize: 17
		qm_Font.family: "Tahoma"
		qm_Font.bold: true
		qm_diagViewCornerRadius: 4
		qm_DiagnosticListComponent: [
			Component
			{
				IGuiListCtrl
				{
					id: qu788529152
					objectName: "qu788529152"
					x: 8
					y: 34
					width: 1260
					height: 560
					totalColumnWidth: 1262
					qm_leftImageID: 52
					qm_leftTileTop: 11
					qm_leftTileBottom: 12
					qm_leftTileRight: 2
					qm_leftTileLeft: 4
					qm_middleImageID: 53
					qm_middleTileTop: 11
					qm_middleTileBottom: 12
					qm_middleTileRight: 2
					qm_middleTileLeft: 2
					qm_rightImageID: 54
					qm_rightTileTop: 11
					qm_rightTileBottom: 12
					qm_rightTileRight: 4
					qm_rightTileLeft: 2
					qm_leftBorderCornerRadius: 2
					qm_tableBackColor: "#ffffffff"
					qm_tableSelectBackColor: "#ff94b6e7"
					qm_tableAlternateBackColor: "#ffe7e7ef"
					qm_tableHeaderBackColor: "#ffefebef"
					qm_tableTextColor: "#ff31344a"
					qm_tableSelectTextColor: "#ffffffff"
					qm_tableAlternateTextColor: "#ff31344a"
					qm_tableMarginLeft: 2
					qm_tableMarginRight: 1
					qm_tableMarginBottom: 1
					qm_tableMarginTop: 1
					qm_tableHeaderTextColor: "#ff31344a"
					qm_tableHeaderValueVarTextAlignmentHorizontal: Text.AlignLeft
					qm_tableHeaderValueVarTextAlignmentVertical: Text.AlignVCenter
					qm_tableHeaderMarginLeft: 3
					qm_tableHeaderMarginRight: 1
					qm_tableHeaderMarginBottom: 1
					qm_tableHeaderMarginTop: 1
					qm_gridLineStyle: 0
					qm_gridLineWidth: 1
					qm_gridLineColor: "#ffffffff"
					qm_noOfColumns: 2
					qm_tableRowHeight: 21
					qm_tableHeaderHeight: 21
					qm_hasHeader: false
					qm_hasGridLines: false
					qm_hasBorder: false
					qm_hasDisplayFocusLine: false
					qm_hasVerticalScrolling: true
					qm_hasVerticalScrollBar: true
					qm_hasHorizontalScrollBar: true
					qm_hasColumnOrdering: true
					qm_hasHighLightFullRow: true
					qm_hasVerUpDownPresent: false
					qm_hasVerPgUpDownPresent: false
					qm_hasHighlight: true
					qm_hasUpDownAsPageUpDown: false
					qm_hasLongAlarmButton: false
					qm_hasExtraPixelForLineHeight: false
					qm_hasRowEditable: false
					qm_hasRowJustification: false
					qm_hasRowJustificationBottom: false
					qm_linesPerRow: 1
					qm_scrollCtrl: qus788529152

					IGuiListColumnView
					{
						id: qc12f000000
						colIndex: 0
						x: 0
						y: 0
						width: 252
						height: 528
						columnType: 0
					}
					IGuiListColumnView
					{
						id: qc22f000000
						colIndex: 1
						x: 252
						y: 0
						width: 1010
						height: 528
						columnType: 0
					}
					IGuiScrollBarCtrl
					{
						id: qus788529152

					}
				}
			},
			Component
			{
				IGuiListCtrl
				{
					id: qu4294967295
					objectName: "qu4294967295"
					x: 8
					y: 34
					width: 1260
					height: 560
					totalColumnWidth: 1228
					qm_leftImageID: 52
					qm_leftTileTop: 11
					qm_leftTileBottom: 12
					qm_leftTileRight: 2
					qm_leftTileLeft: 4
					qm_middleImageID: 53
					qm_middleTileTop: 11
					qm_middleTileBottom: 12
					qm_middleTileRight: 2
					qm_middleTileLeft: 2
					qm_rightImageID: 54
					qm_rightTileTop: 11
					qm_rightTileBottom: 12
					qm_rightTileRight: 4
					qm_rightTileLeft: 2
					qm_leftBorderCornerRadius: 2
					qm_tableBackColor: "#ffffffff"
					qm_tableSelectBackColor: "#ff94b6e7"
					qm_tableAlternateBackColor: "#ffe7e7ef"
					qm_tableHeaderBackColor: "#ffefebef"
					qm_tableTextColor: "#ff31344a"
					qm_tableSelectTextColor: "#ffffffff"
					qm_tableAlternateTextColor: "#ff31344a"
					qm_tableMarginLeft: 2
					qm_tableMarginRight: 1
					qm_tableMarginBottom: 1
					qm_tableMarginTop: 1
					qm_tableHeaderTextColor: "#ff31344a"
					qm_tableHeaderValueVarTextAlignmentHorizontal: Text.AlignLeft
					qm_tableHeaderValueVarTextAlignmentVertical: Text.AlignVCenter
					qm_tableHeaderMarginLeft: 3
					qm_tableHeaderMarginRight: 1
					qm_tableHeaderMarginBottom: 1
					qm_tableHeaderMarginTop: 1
					qm_gridLineStyle: 0
					qm_gridLineWidth: 1
					qm_gridLineColor: "#ffffffff"
					qm_noOfColumns: 5
					qm_tableRowHeight: 21
					qm_tableHeaderHeight: 21
					qm_hasHeader: true
					qm_hasGridLines: true
					qm_hasBorder: false
					qm_hasDisplayFocusLine: true
					qm_hasVerticalScrolling: true
					qm_hasVerticalScrollBar: true
					qm_hasHorizontalScrollBar: true
					qm_hasColumnOrdering: true
					qm_hasHighLightFullRow: true
					qm_hasVerUpDownPresent: false
					qm_hasVerPgUpDownPresent: false
					qm_hasHighlight: true
					qm_hasUpDownAsPageUpDown: false
					qm_hasLongAlarmButton: false
					qm_hasExtraPixelForLineHeight: false
					qm_hasRowEditable: false
					qm_hasRowJustification: false
					qm_hasRowJustificationBottom: false
					qm_linesPerRow: 1
					qm_scrollCtrl: qus4294967295

					IGuiListColumnView
					{
						id: qc1ffffffff
						colIndex: 0
						x: 0
						y: 0
						width: 24
						height: 528
						columnType: 1
						qm_columnValueVarTextAlignmentHorizontal: Image.AlignLeft
						qm_columnValueVarTextAlignmentVertical: Image.AlignVCenter
					}
					IGuiListColumnView
					{
						id: qc2ffffffff
						colIndex: 1
						x: 24
						y: 0
						width: 24
						height: 528
						columnType: 0
						qm_columnValueVarTextAlignmentHorizontal: Text.AlignLeft
						qm_columnValueVarTextAlignmentVertical: Text.AlignVCenter
					}
					IGuiListColumnView
					{
						id: qc3ffffffff
						colIndex: 2
						x: 48
						y: 0
						width: 100
						height: 528
						columnType: 0
						qm_columnValueVarTextAlignmentHorizontal: Text.AlignLeft
						qm_columnValueVarTextAlignmentVertical: Text.AlignVCenter
					}
					IGuiListColumnView
					{
						id: qc4ffffffff
						colIndex: 3
						x: 148
						y: 0
						width: 100
						height: 528
						columnType: 0
						qm_columnValueVarTextAlignmentHorizontal: Text.AlignLeft
						qm_columnValueVarTextAlignmentVertical: Text.AlignVCenter
					}
					IGuiListColumnView
					{
						id: qc5ffffffff
						colIndex: 4
						x: 248
						y: 0
						width: 980
						height: 528
						columnType: 0
						qm_columnValueVarTextAlignmentHorizontal: Text.AlignLeft
						qm_columnValueVarTextAlignmentVertical: Text.AlignVCenter
					}
					IGuiScrollBarCtrl
					{
						id: qus4294967295

					}
				}
			},
			Component
			{
				IGuiListCtrl
				{
					id: qu4294967294
					objectName: "qu4294967294"
					x: 8
					y: 34
					width: 1260
					height: 560
					totalColumnWidth: 1262
					qm_leftImageID: 52
					qm_leftTileTop: 11
					qm_leftTileBottom: 12
					qm_leftTileRight: 2
					qm_leftTileLeft: 4
					qm_middleImageID: 53
					qm_middleTileTop: 11
					qm_middleTileBottom: 12
					qm_middleTileRight: 2
					qm_middleTileLeft: 2
					qm_rightImageID: 54
					qm_rightTileTop: 11
					qm_rightTileBottom: 12
					qm_rightTileRight: 4
					qm_rightTileLeft: 2
					qm_leftBorderCornerRadius: 2
					qm_tableBackColor: "#ffffffff"
					qm_tableSelectBackColor: "#ff94b6e7"
					qm_tableAlternateBackColor: "#ffe7e7ef"
					qm_tableHeaderBackColor: "#ffefebef"
					qm_tableTextColor: "#ff31344a"
					qm_tableSelectTextColor: "#ffffffff"
					qm_tableAlternateTextColor: "#ff31344a"
					qm_tableMarginLeft: 2
					qm_tableMarginRight: 1
					qm_tableMarginBottom: 1
					qm_tableMarginTop: 1
					qm_tableHeaderTextColor: "#ff31344a"
					qm_tableHeaderValueVarTextAlignmentHorizontal: Text.AlignLeft
					qm_tableHeaderValueVarTextAlignmentVertical: Text.AlignVCenter
					qm_tableHeaderMarginLeft: 3
					qm_tableHeaderMarginRight: 1
					qm_tableHeaderMarginBottom: 1
					qm_tableHeaderMarginTop: 1
					qm_gridLineStyle: 0
					qm_gridLineWidth: 1
					qm_gridLineColor: "#ffffffff"
					qm_noOfColumns: 1
					qm_tableRowHeight: 21
					qm_tableHeaderHeight: 21
					qm_hasHeader: false
					qm_hasGridLines: false
					qm_hasBorder: false
					qm_hasDisplayFocusLine: true
					qm_hasVerticalScrolling: true
					qm_hasVerticalScrollBar: true
					qm_hasHorizontalScrollBar: true
					qm_hasColumnOrdering: true
					qm_hasHighLightFullRow: false
					qm_hasVerUpDownPresent: false
					qm_hasVerPgUpDownPresent: false
					qm_hasHighlight: false
					qm_hasUpDownAsPageUpDown: false
					qm_hasLongAlarmButton: false
					qm_hasExtraPixelForLineHeight: false
					qm_hasRowEditable: false
					qm_hasRowJustification: false
					qm_hasRowJustificationBottom: false
					qm_linesPerRow: 1
					qm_scrollCtrl: qus4294967294

					IGuiListColumnView
					{
						id: qc1fffffffe
						colIndex: 0
						x: 0
						y: 0
						width: 1262
						height: 528
						columnType: 0
					}
					IGuiScrollBarCtrl
					{
						id: qus4294967294

					}
				}
			}
		]
		IGuiGraphicButton
		{
			id: q486539311
			objId: 486539311
			x: 68
			y: 600
			width: 56
			height: 40
			qm_BorderCornerRadius: 3
			qm_BorderWidth: 1
			qm_ImageSource: "image://QSmartImageProvider/55#2#4#128#0#0"
			qm_Border.top: 15
			qm_Border.bottom: 15
			qm_Border.right: 5
			qm_Border.left: 5
			qm_FillColor: "#ffefebef"
			qm_FocusWidth: 2
			qm_FocusColor: "#ffa5cfd6"
			qm_ImageFillMode:6
			qm_ImagePossitionX: 3
			qm_ImagePossitionY: 2
			qm_ImageWidth: 51
			qm_ImageHeight: 36
			qm_SourceSizeWidth: 51
			qm_SourceSizeHeight: 36
		}
		IGuiGraphicButton
		{
			id: q486539312
			objId: 486539312
			x: 129
			y: 600
			width: 56
			height: 40
			qm_BorderCornerRadius: 3
			qm_BorderWidth: 1
			qm_ImageSource: "image://QSmartImageProvider/55#2#4#128#0#0"
			qm_Border.top: 15
			qm_Border.bottom: 15
			qm_Border.right: 5
			qm_Border.left: 5
			qm_FillColor: "#ffefebef"
			qm_FocusWidth: 2
			qm_FocusColor: "#ffa5cfd6"
			qm_ImageFillMode:6
			qm_ImagePossitionX: 3
			qm_ImagePossitionY: 2
			qm_ImageWidth: 51
			qm_ImageHeight: 36
			qm_SourceSizeWidth: 51
			qm_SourceSizeHeight: 36
		}
		IGuiGraphicButton
		{
			id: q486539313
			objId: 486539313
			x: 190
			y: 600
			width: 56
			height: 40
			qm_BorderCornerRadius: 3
			qm_BorderWidth: 1
			qm_ImageSource: "image://QSmartImageProvider/55#2#4#128#0#0"
			qm_Border.top: 15
			qm_Border.bottom: 15
			qm_Border.right: 5
			qm_Border.left: 5
			qm_FillColor: "#ffefebef"
			qm_FocusWidth: 2
			qm_FocusColor: "#ffa5cfd6"
			qm_ImageFillMode:6
			qm_ImagePossitionX: 3
			qm_ImagePossitionY: 2
			qm_ImageWidth: 51
			qm_ImageHeight: 36
			qm_SourceSizeWidth: 51
			qm_SourceSizeHeight: 36
		}
		IGuiGraphicButton
		{
			id: q486539314
			objId: 486539314
			x: 7
			y: 600
			width: 56
			height: 40
			qm_BorderCornerRadius: 3
			qm_BorderWidth: 1
			qm_ImageSource: "image://QSmartImageProvider/55#2#4#128#0#0"
			qm_Border.top: 15
			qm_Border.bottom: 15
			qm_Border.right: 5
			qm_Border.left: 5
			qm_FillColor: "#ffefebef"
			qm_FocusWidth: 2
			qm_FocusColor: "#ffa5cfd6"
			qm_ImageFillMode:6
			qm_ImagePossitionX: 3
			qm_ImagePossitionY: 2
			qm_ImageWidth: 51
			qm_ImageHeight: 36
			qm_SourceSizeWidth: 51
			qm_SourceSizeHeight: 36
		}
		IGuiGraphicButton
		{
			id: q486539315
			objId: 486539315
			x: 190
			y: 600
			width: 56
			height: 40
			qm_BorderCornerRadius: 3
			qm_BorderWidth: 1
			qm_ImageSource: "image://QSmartImageProvider/55#2#4#128#0#0"
			qm_Border.top: 15
			qm_Border.bottom: 15
			qm_Border.right: 5
			qm_Border.left: 5
			qm_FillColor: "#ffefebef"
			qm_FocusWidth: 2
			qm_FocusColor: "#ffa5cfd6"
			qm_ImageFillMode:6
			qm_ImagePossitionX: 3
			qm_ImagePossitionY: 2
			qm_ImageWidth: 51
			qm_ImageHeight: 36
			qm_SourceSizeWidth: 51
			qm_SourceSizeHeight: 36
		}
	}
	IGuiButton
	{
		id: q486539316
		objId: 486539316
		x: 1
		y: 49
		width: 159
		height: 47
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 1
		qm_ImageSource: "image://QSmartImageProvider/21#2#4#128#0#0"
		qm_Border.top: 15
		qm_Border.bottom: 15
		qm_Border.right: 5
		qm_Border.left: 5
		qm_FillColor: "#ffe7e3e7"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 1
		qm_Anchors.leftMargin: 1
		qm_Anchors.rightMargin: 1
		qm_Anchors.topMargin: 1
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
}
